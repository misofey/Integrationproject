#ifndef RTW_HEADER_reaction_pendulum_acc_h_
#define RTW_HEADER_reaction_pendulum_acc_h_
#include <stddef.h>
#include <emmintrin.h>
#include <string.h>
#ifndef reaction_pendulum_acc_COMMON_INCLUDES_
#define reaction_pendulum_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn
#define S_FUNCTION_LEVEL 2
#ifndef RTW_GENERATED_S_FUNCTION
#define RTW_GENERATED_S_FUNCTION
#endif
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "reaction_pendulum_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T B_5_0_0 [ 4 ] ; real_T B_5_1_0 ; real_T B_5_2_0 ;
real_T B_5_4_0 ; real_T B_5_6_0 [ 2 ] ; real_T B_5_7_0 ; real_T B_5_7_1 ;
real_T B_5_7_2 ; real_T B_5_7_3 ; real_T B_5_7_4 ; real_T B_5_7_5 ; real_T
B_5_7_6 [ 2 ] ; real_T B_5_9_0 ; real_T B_5_11_0 ; real_T B_5_17_0 ; real_T
B_5_18_0 ; real_T B_5_19_0 ; real_T B_5_20_0 ; real_T B_5_35_0 [ 4 ] ; real_T
B_5_0_0_m [ 3 ] ; real_T B_5_1_0_c ; real_T B_5_3_0 [ 4 ] ; real_T B_5_4_0_k
[ 16 ] ; real_T B_5_5_0 [ 4 ] ; real_T B_5_6_0_c [ 16 ] ; real_T B_5_7_0_b [
16 ] ; real_T B_5_8_0 [ 16 ] ; real_T B_5_11_0_p [ 4 ] ; real_T B_5_13_0 [ 4
] ; real_T B_5_15_0 ; real_T B_5_16_0 ; real_T B_5_17_0_c ; real_T B_5_18_0_f
; real_T B_4_0_1 ; real_T B_3_0_1 ; real_T B_2_0_0 [ 4 ] ; real_T B_2_1_1 ;
real_T B_2_1_2 ; real_T B_1_4_0 [ 4 ] ; real_T B_0_0_1 [ 16 ] ; boolean_T
B_5_9_0_g ; boolean_T B_5_12_0 ; char_T pad_B_5_12_0 [ 6 ] ; }
B_reaction_pendulum_T ; typedef struct { real_T MemoryX_DSTATE [ 4 ] ; real_T
UD_DSTATE ; real_T Memory1_PreviousInput ; real_T Memory_PreviousInput ; void
* PlotState_PWORK [ 9 ] ; void * ToWorkspace_PWORK ; void *
ToWorkspace1_PWORK ; void * ToWorkspace2_PWORK ; void * ToWorkspace3_PWORK ;
void * ToWorkspace4_PWORK ; int32_T MATLABFunction2_sysIdxToRun ; int32_T
MATLABFunction1_sysIdxToRun ; int32_T MATLABFunction_sysIdxToRun ; int32_T
MeasurementUpdate_sysIdxToRun ; int32_T SqrtUsedFcn_sysIdxToRun ; int8_T
MeasurementUpdate_SubsysRanBC ; boolean_T icLoad ; boolean_T
MeasurementUpdate_MODE ; char_T pad_MeasurementUpdate_MODE [ 1 ] ; }
DW_reaction_pendulum_T ; struct P_reaction_pendulum_T_ { real_T P_0 ; real_T
P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 [ 2 ] ; real_T P_5 [ 2 ] ; real_T
P_6 ; real_T P_7 [ 2 ] ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11
; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ;
real_T P_17 ; real_T P_18 ; real_T P_19 [ 3 ] ; real_T P_20 ; real_T P_21 ;
real_T P_22 [ 4 ] ; real_T P_23 [ 16 ] ; real_T P_24 [ 4 ] ; real_T P_25 [ 16
] ; real_T P_26 [ 16 ] ; real_T P_27 [ 16 ] ; real_T P_28 [ 4 ] ; real_T P_29
[ 4 ] ; real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; boolean_T
P_34 ; boolean_T P_35 ; uint8_T P_36 ; uint8_T P_37 ; char_T pad_P_37 [ 4 ] ;
} ; extern P_reaction_pendulum_T reaction_pendulum_rtDefaultP ;
#endif
