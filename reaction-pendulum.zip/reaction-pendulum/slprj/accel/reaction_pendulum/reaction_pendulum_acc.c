#include <math.h>
#include "reaction_pendulum_acc.h"
#include "reaction_pendulum_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simtarget/slSimTgtMdlrefSfcnBridge.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
void rt_ssGetBlockPath ( SimStruct * S , int_T sysIdx , int_T blkIdx , char_T
* * path ) { _ssGetBlockPath ( S , sysIdx , blkIdx , path ) ; } void
rt_ssSet_slErrMsg ( void * S , void * diag ) { SimStruct * castedS = (
SimStruct * ) S ; if ( ! _ssIsErrorStatusAslErrMsg ( castedS ) ) {
_ssSet_slErrMsg ( castedS , diag ) ; } else { _ssDiscardDiagnostic ( castedS
, diag ) ; } } void rt_ssReportDiagnosticAsWarning ( void * S , void * diag )
{ _ssReportDiagnosticAsWarning ( ( SimStruct * ) S , diag ) ; } void
rt_ssReportDiagnosticAsInfo ( void * S , void * diag ) {
_ssReportDiagnosticAsInfo ( ( SimStruct * ) S , diag ) ; } static void
mdlOutputs ( SimStruct * S , int_T tid ) { __m128d tmp_2 ; __m128d tmp_3 ;
__m128d tmp_4 ; __m128d tmp_5 ; __m128d tmp_6 ; __m128d tmp_7 ;
B_reaction_pendulum_T * _rtB ; DW_reaction_pendulum_T * _rtDW ;
P_reaction_pendulum_T * _rtP ; real_T B_5_33_0 [ 4 ] ; real_T rtb_B_5_33_0 [
4 ] ; real_T tmp [ 4 ] ; real_T tmp_0 [ 4 ] ; real_T rtb_B_5_5_0 ; real_T
tmp_1 ; int32_T i ; _rtDW = ( ( DW_reaction_pendulum_T * ) ssGetRootDWork ( S
) ) ; _rtP = ( ( P_reaction_pendulum_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_reaction_pendulum_T * ) _ssGetModelBlockIO ( S ) ) ; if ( _rtDW -> icLoad )
{ _rtDW -> MemoryX_DSTATE [ 0 ] = _rtB -> B_5_13_0 [ 0 ] ; _rtDW ->
MemoryX_DSTATE [ 1 ] = _rtB -> B_5_13_0 [ 1 ] ; _rtDW -> MemoryX_DSTATE [ 2 ]
= _rtB -> B_5_13_0 [ 2 ] ; _rtDW -> MemoryX_DSTATE [ 3 ] = _rtB -> B_5_13_0 [
3 ] ; } _rtB -> B_5_0_0 [ 0 ] = _rtDW -> MemoryX_DSTATE [ 0 ] ; _rtB ->
B_5_0_0 [ 1 ] = _rtDW -> MemoryX_DSTATE [ 1 ] ; _rtB -> B_5_0_0 [ 2 ] = _rtDW
-> MemoryX_DSTATE [ 2 ] ; _rtB -> B_5_0_0 [ 3 ] = _rtDW -> MemoryX_DSTATE [ 3
] ; ssCallAccelRunBlock ( S , 5 , 1 , SS_CALL_MDL_OUTPUTS ) ; if ( _rtP ->
P_36 == 1 ) { _rtB -> B_5_2_0 = _rtB -> B_5_1_0_c ; } else { _rtB -> B_5_2_0
= _rtB -> B_5_1_0 ; } rtb_B_5_5_0 = _rtP -> P_1 * _rtB -> B_5_2_0 ; if (
rtb_B_5_5_0 > _rtP -> P_2 ) { _rtB -> B_5_4_0 = _rtP -> P_2 ; } else if (
rtb_B_5_5_0 < _rtP -> P_3 ) { _rtB -> B_5_4_0 = _rtP -> P_3 ; } else { _rtB
-> B_5_4_0 = rtb_B_5_5_0 ; } if ( _rtP -> P_37 == 1 ) { rtb_B_5_5_0 = _rtB ->
B_5_18_0_f ; } else { rtb_B_5_5_0 = _rtB -> B_5_15_0 ; } _rtB -> B_5_6_0 [ 0
] = _rtP -> P_4 [ 0 ] * rtb_B_5_5_0 ; _rtB -> B_5_6_0 [ 1 ] = _rtP -> P_4 [ 1
] * rtb_B_5_5_0 ; ssCallAccelRunBlock ( S , 5 , 7 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> B_5_9_0 = _rtP -> P_9 * _rtB -> B_5_7_1 * _rtP -> P_10 ;
ssCallAccelRunBlock ( S , 3 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_5_11_0 =
_rtP -> P_11 * _rtB -> B_5_7_2 ; _rtB -> B_5_17_0 = ( _rtB -> B_5_7_5 - _rtDW
-> Memory_PreviousInput ) * _rtP -> P_15 ; _rtB -> B_5_18_0 = ( _rtB ->
B_5_11_0 - _rtDW -> Memory1_PreviousInput ) * _rtP -> P_13 / _rtB -> B_5_17_0
; _rtB -> B_5_19_0 = _rtP -> P_16 * _rtB -> B_5_7_3 ; _rtB -> B_5_20_0 = _rtB
-> B_3_0_1 * _rtP -> P_17 ; rtb_B_5_5_0 = _rtB -> B_5_20_0 - _rtDW ->
UD_DSTATE ; _rtB -> B_2_0_0 [ 0 ] = _rtB -> B_3_0_1 ; _rtB -> B_2_0_0 [ 1 ] =
_rtB -> B_5_18_0 ; _rtB -> B_2_0_0 [ 2 ] = _rtB -> B_5_19_0 ; _rtB -> B_2_0_0
[ 3 ] = rtb_B_5_5_0 ; ssCallAccelRunBlock ( S , 2 , 1 , SS_CALL_MDL_OUTPUTS )
; ssCallAccelRunBlock ( S , 5 , 24 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 25 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 26 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 27 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 28 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 29 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; for ( i = 0 ; i <=
2 ; i += 2 ) { tmp_3 = _mm_loadu_pd ( & _rtB -> B_5_4_0_k [ i ] ) ; tmp_4 =
_mm_loadu_pd ( & _rtB -> B_5_4_0_k [ i + 4 ] ) ; tmp_5 = _mm_loadu_pd ( &
_rtB -> B_5_4_0_k [ i + 8 ] ) ; tmp_6 = _mm_loadu_pd ( & _rtB -> B_5_4_0_k [
i + 12 ] ) ; tmp_7 = _mm_loadu_pd ( & _rtB -> B_5_5_0 [ i ] ) ; _mm_storeu_pd
( & tmp_0 [ i ] , tmp_7 ) ; _mm_storeu_pd ( & tmp [ i ] , _mm_add_pd (
_mm_mul_pd ( tmp_6 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 3 ] ) ) , _mm_add_pd (
_mm_mul_pd ( tmp_5 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 2 ] ) ) , _mm_add_pd (
_mm_mul_pd ( tmp_4 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 1 ] ) ) , _mm_add_pd (
_mm_mul_pd ( tmp_3 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 0 ] ) ) , _mm_set1_pd (
0.0 ) ) ) ) ) ) ; } tmp_1 = _rtB -> B_5_2_0 ; rtb_B_5_33_0 [ 0 ] = _rtB ->
B_3_0_1 ; rtb_B_5_33_0 [ 1 ] = _rtB -> B_5_18_0 ; rtb_B_5_33_0 [ 2 ] = _rtB
-> B_5_19_0 ; rtb_B_5_33_0 [ 3 ] = rtb_B_5_5_0 ; if ( _rtB -> B_5_12_0 ) { if
( ! _rtDW -> MeasurementUpdate_MODE ) { if ( ssGetTaskTime ( S , 1 ) !=
ssGetTStart ( S ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; }
_rtDW -> MeasurementUpdate_MODE = true ; } for ( i = 0 ; i <= 2 ; i += 2 ) {
tmp_3 = _mm_loadu_pd ( & _rtB -> B_5_6_0_c [ i ] ) ; tmp_4 = _mm_loadu_pd ( &
_rtB -> B_5_6_0_c [ i + 4 ] ) ; tmp_5 = _mm_loadu_pd ( & _rtB -> B_5_6_0_c [
i + 8 ] ) ; tmp_6 = _mm_loadu_pd ( & _rtB -> B_5_6_0_c [ i + 12 ] ) ; tmp_7 =
_mm_loadu_pd ( & _rtB -> B_5_11_0_p [ i ] ) ; tmp_2 = _mm_loadu_pd ( &
rtb_B_5_33_0 [ i ] ) ; _mm_storeu_pd ( & B_5_33_0 [ i ] , _mm_sub_pd ( tmp_2
, _mm_add_pd ( _mm_mul_pd ( tmp_7 , _mm_set1_pd ( _rtB -> B_5_2_0 ) ) ,
_mm_add_pd ( _mm_mul_pd ( tmp_6 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 3 ] ) ) ,
_mm_add_pd ( _mm_mul_pd ( tmp_5 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 2 ] ) ) ,
_mm_add_pd ( _mm_mul_pd ( tmp_4 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 1 ] ) ) ,
_mm_add_pd ( _mm_mul_pd ( tmp_3 , _mm_set1_pd ( _rtB -> B_5_0_0 [ 0 ] ) ) ,
_mm_set1_pd ( 0.0 ) ) ) ) ) ) ) ) ; } for ( i = 0 ; i <= 2 ; i += 2 ) {
_mm_storeu_pd ( & _rtB -> B_1_4_0 [ i ] , _mm_set1_pd ( 0.0 ) ) ; tmp_3 =
_mm_loadu_pd ( & _rtB -> B_5_8_0 [ i ] ) ; tmp_4 = _mm_loadu_pd ( & _rtB ->
B_1_4_0 [ i ] ) ; _mm_storeu_pd ( & _rtB -> B_1_4_0 [ i ] , _mm_add_pd (
_mm_mul_pd ( tmp_3 , _mm_set1_pd ( B_5_33_0 [ 0 ] ) ) , tmp_4 ) ) ; tmp_3 =
_mm_loadu_pd ( & _rtB -> B_5_8_0 [ i + 4 ] ) ; tmp_4 = _mm_loadu_pd ( & _rtB
-> B_1_4_0 [ i ] ) ; _mm_storeu_pd ( & _rtB -> B_1_4_0 [ i ] , _mm_add_pd (
_mm_mul_pd ( tmp_3 , _mm_set1_pd ( B_5_33_0 [ 1 ] ) ) , tmp_4 ) ) ; tmp_3 =
_mm_loadu_pd ( & _rtB -> B_5_8_0 [ i + 8 ] ) ; tmp_4 = _mm_loadu_pd ( & _rtB
-> B_1_4_0 [ i ] ) ; _mm_storeu_pd ( & _rtB -> B_1_4_0 [ i ] , _mm_add_pd (
_mm_mul_pd ( tmp_3 , _mm_set1_pd ( B_5_33_0 [ 2 ] ) ) , tmp_4 ) ) ; tmp_3 =
_mm_loadu_pd ( & _rtB -> B_5_8_0 [ i + 12 ] ) ; tmp_4 = _mm_loadu_pd ( & _rtB
-> B_1_4_0 [ i ] ) ; _mm_storeu_pd ( & _rtB -> B_1_4_0 [ i ] , _mm_add_pd (
_mm_mul_pd ( tmp_3 , _mm_set1_pd ( B_5_33_0 [ 3 ] ) ) , tmp_4 ) ) ; }
srUpdateBC ( _rtDW -> MeasurementUpdate_SubsysRanBC ) ; } else if ( _rtDW ->
MeasurementUpdate_MODE ) { ssSetBlockStateForSolverChangedAtMajorStep ( S ) ;
_rtB -> B_1_4_0 [ 0 ] = _rtP -> P_0 ; _rtB -> B_1_4_0 [ 1 ] = _rtP -> P_0 ;
_rtB -> B_1_4_0 [ 2 ] = _rtP -> P_0 ; _rtB -> B_1_4_0 [ 3 ] = _rtP -> P_0 ;
_rtDW -> MeasurementUpdate_MODE = false ; } _rtB -> B_5_35_0 [ 0 ] = ( tmp_0
[ 0 ] * tmp_1 + tmp [ 0 ] ) + _rtB -> B_1_4_0 [ 0 ] ; _rtB -> B_5_35_0 [ 1 ]
= ( tmp_0 [ 1 ] * tmp_1 + tmp [ 1 ] ) + _rtB -> B_1_4_0 [ 1 ] ; _rtB ->
B_5_35_0 [ 2 ] = ( tmp_0 [ 2 ] * tmp_1 + tmp [ 2 ] ) + _rtB -> B_1_4_0 [ 2 ]
; _rtB -> B_5_35_0 [ 3 ] = ( tmp_0 [ 3 ] * tmp_1 + tmp [ 3 ] ) + _rtB ->
B_1_4_0 [ 3 ] ; ssCallAccelRunBlock ( S , 5 , 36 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 37 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 5 , 38 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 4 , 0 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER (
tid ) ; } static void mdlOutputsTID2 ( SimStruct * S , int_T tid ) {
B_reaction_pendulum_T * _rtB ; P_reaction_pendulum_T * _rtP ; _rtP = ( (
P_reaction_pendulum_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_reaction_pendulum_T * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> B_5_0_0_m [ 0
] = _rtP -> P_19 [ 0 ] ; _rtB -> B_5_0_0_m [ 1 ] = _rtP -> P_19 [ 1 ] ; _rtB
-> B_5_0_0_m [ 2 ] = _rtP -> P_19 [ 2 ] ; _rtB -> B_5_1_0_c = _rtP -> P_20 ;
_rtB -> B_5_3_0 [ 0 ] = _rtP -> P_21 * _rtP -> P_22 [ 0 ] ; _rtB -> B_5_3_0 [
1 ] = _rtP -> P_21 * _rtP -> P_22 [ 1 ] ; _rtB -> B_5_3_0 [ 2 ] = _rtP ->
P_21 * _rtP -> P_22 [ 2 ] ; _rtB -> B_5_3_0 [ 3 ] = _rtP -> P_21 * _rtP ->
P_22 [ 3 ] ; _rtB -> B_5_5_0 [ 0 ] = _rtP -> P_24 [ 0 ] ; _rtB -> B_5_5_0 [ 1
] = _rtP -> P_24 [ 1 ] ; _rtB -> B_5_5_0 [ 2 ] = _rtP -> P_24 [ 2 ] ; _rtB ->
B_5_5_0 [ 3 ] = _rtP -> P_24 [ 3 ] ; memcpy ( & _rtB -> B_5_4_0_k [ 0 ] , &
_rtP -> P_23 [ 0 ] , sizeof ( real_T ) << 4U ) ; memcpy ( & _rtB -> B_5_6_0_c
[ 0 ] , & _rtP -> P_25 [ 0 ] , sizeof ( real_T ) << 4U ) ; memcpy ( & _rtB ->
B_5_7_0_b [ 0 ] , & _rtP -> P_26 [ 0 ] , sizeof ( real_T ) << 4U ) ; memcpy (
& _rtB -> B_5_8_0 [ 0 ] , & _rtP -> P_27 [ 0 ] , sizeof ( real_T ) << 4U ) ;
_rtB -> B_5_9_0_g = _rtP -> P_34 ; _rtB -> B_5_12_0 = _rtP -> P_35 ; _rtB ->
B_5_11_0_p [ 0 ] = _rtP -> P_28 [ 0 ] ; _rtB -> B_5_13_0 [ 0 ] = _rtP -> P_29
[ 0 ] ; _rtB -> B_5_11_0_p [ 1 ] = _rtP -> P_28 [ 1 ] ; _rtB -> B_5_13_0 [ 1
] = _rtP -> P_29 [ 1 ] ; _rtB -> B_5_11_0_p [ 2 ] = _rtP -> P_28 [ 2 ] ; _rtB
-> B_5_13_0 [ 2 ] = _rtP -> P_29 [ 2 ] ; _rtB -> B_5_11_0_p [ 3 ] = _rtP ->
P_28 [ 3 ] ; _rtB -> B_5_13_0 [ 3 ] = _rtP -> P_29 [ 3 ] ; _rtB -> B_5_15_0 =
_rtP -> P_30 ; _rtB -> B_5_16_0 = _rtP -> P_31 ; _rtB -> B_5_17_0_c = _rtP ->
P_32 ; _rtB -> B_5_18_0_f = _rtP -> P_33 ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { B_reaction_pendulum_T *
_rtB ; DW_reaction_pendulum_T * _rtDW ; _rtDW = ( ( DW_reaction_pendulum_T *
) ssGetRootDWork ( S ) ) ; _rtB = ( ( B_reaction_pendulum_T * )
_ssGetModelBlockIO ( S ) ) ; _rtDW -> icLoad = false ; _rtDW ->
MemoryX_DSTATE [ 0 ] = _rtB -> B_5_35_0 [ 0 ] ; _rtDW -> MemoryX_DSTATE [ 1 ]
= _rtB -> B_5_35_0 [ 1 ] ; _rtDW -> MemoryX_DSTATE [ 2 ] = _rtB -> B_5_35_0 [
2 ] ; _rtDW -> MemoryX_DSTATE [ 3 ] = _rtB -> B_5_35_0 [ 3 ] ; _rtDW ->
Memory1_PreviousInput = _rtB -> B_5_11_0 ; _rtDW -> Memory_PreviousInput =
_rtB -> B_5_7_5 ; _rtDW -> UD_DSTATE = _rtB -> B_5_20_0 ; UNUSED_PARAMETER (
tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; } static void mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal
( S , 0 , 1849824294U ) ; ssSetChecksumVal ( S , 1 , 1729648896U ) ;
ssSetChecksumVal ( S , 2 , 4166957546U ) ; ssSetChecksumVal ( S , 3 ,
2622937417U ) ; { mxArray * slVerStructMat = ( NULL ) ; mxArray * slStrMat =
mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status =
mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if ( status
== 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 , "Version" ) ;
if ( slVerMat == ( NULL ) ) { status = 1 ; } else { status = mxGetString (
slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "10.4" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != ( SLSize )
sizeof ( DW_reaction_pendulum_T ) ) { static char msg [ 256 ] ; snprintf (
msg , 256 , "Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file (%ld vs %lu)." , ( signed long )
ssGetSizeofDWork ( S ) , ( unsigned long ) sizeof ( DW_reaction_pendulum_T )
) ; ssSetErrorStatus ( S , msg ) ; } if ( ssGetSizeofGlobalBlockIO ( S ) != (
SLSize ) sizeof ( B_reaction_pendulum_T ) ) { static char msg [ 256 ] ;
snprintf ( msg , 256 , "Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file (%ld vs %lu)." , ( signed long )
ssGetSizeofGlobalBlockIO ( S ) , ( unsigned long ) sizeof (
B_reaction_pendulum_T ) ) ; ssSetErrorStatus ( S , msg ) ; } { int
ssSizeofParams ; ssGetSizeofParams ( S , & ssSizeofParams ) ; if (
ssSizeofParams != sizeof ( P_reaction_pendulum_T ) ) { static char msg [ 256
] ; snprintf ( msg , 256 , "Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file (%d vs %lu)." , ssSizeofParams , (
unsigned long ) sizeof ( P_reaction_pendulum_T ) ) ; ssSetErrorStatus ( S ,
msg ) ; } } _ssSetModelRtp ( S , ( real_T * ) & reaction_pendulum_rtDefaultP
) ; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct * childS ;
SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ; callSysFcns
= ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 1 ) ; callSysFcns =
ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 2 ) ; callSysFcns =
ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; childS = ssGetSFunction ( S , 3 ) ; callSysFcns =
ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; } slAccRegPrmChangeFcn ( S , mdlOutputsTID2 ) ; }
static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
